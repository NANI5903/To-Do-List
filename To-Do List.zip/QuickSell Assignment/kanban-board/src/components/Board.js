import React, { useEffect, useState } from 'react';
import { fetchTickets } from '../services/api';

// Importing SVG icons for each status and actions
import todoIcon from '../icons_FEtask/To-do.svg';
import inprogressIcon from '../icons_FEtask/in-progress.svg';
import backlogIcon from '../icons_FEtask/Backlog.svg';
import addIcon from '../icons_FEtask/add.svg';
import threeDotsIcon from '../icons_FEtask/3 dot menu.svg';
import doneIcon from '../icons_FEtask/Done.svg';
import canceledIcon from '../icons_FEtask/Cancelled.svg';
import displayIcon from '../icons_FEtask/Display.svg'; // Import Display.svg
import downIcon from '../icons_FEtask/down.svg';

// Import priority headers
import highPriorityIcon from '../icons_FEtask/Img - High Priority.svg';
import mediumPriorityIcon from '../icons_FEtask/Img - Medium Priority.svg';
import lowPriorityIcon from '../icons_FEtask/Img - Low Priority.svg';
import noPriorityIcon from '../icons_FEtask/No-priority.svg'; // Import No-priority.svg
import Urgent from '../icons_FEtask/SVG - Urgent Priority colour.svg'; // Import Urgent.svg

const priorityOptions = ["No Priority", "Urgent", "High", "Medium", "Low"];
const randomLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

const getRandomPriority = () => {
    return priorityOptions[Math.floor(Math.random() * priorityOptions.length)];
};

const getRandomLetter = () => {
    return randomLetters.charAt(Math.floor(Math.random() * randomLetters.length));
};

const randomUserImages = [
    'https://randomuser.me/api/portraits/men/1.jpg',
    'https://randomuser.me/api/portraits/women/2.jpg',
    'https://randomuser.me/api/portraits/men/3.jpg',
    'https://randomuser.me/api/portraits/women/4.jpg',
    'https://randomuser.me/api/portraits/men/5.jpg',
    'https://randomuser.me/api/portraits/women/6.jpg',
    'https://randomuser.me/api/portraits/men/7.jpg',
    'https://randomuser.me/api/portraits/women/8.jpg',
    'https://randomuser.me/api/portraits/men/9.jpg',
    'https://randomuser.me/api/portraits/women/10.jpg',
    'https://randomuser.me/api/portraits/men/11.jpg',
    'https://randomuser.me/api/portraits/women/12.jpg',
    'https://randomuser.me/api/portraits/men/13.jpg',
    'https://randomuser.me/api/portraits/women/14.jpg',
    'https://randomuser.me/api/portraits/men/15.jpg',
    'https://randomuser.me/api/portraits/women/16.jpg',
];

const predefinedUsers = {
    'Nani': randomUserImages[0],
    'Pravallika': randomUserImages[1],
    'Vikram Adthia': randomUserImages[2],
};

const Board = () => {
    const [tickets, setTickets] = useState([]);
    const [groupBy, setGroupBy] = useState('status');
    const [orderBy, setOrderBy] = useState('title');
    const [displayOptionsOpen, setDisplayOptionsOpen] = useState(false);

    useEffect(() => {
        const getTickets = async () => {
            const fetchedTickets = await fetchTickets();
            const ticketsWithUsers = fetchedTickets.tickets.map((ticket, index) => {
                ticket.user = index % 3 === 0 ? 'Nani' : index % 3 === 1 ? 'Pravallika' : 'Vikram Adthia';
                ticket.priority = getRandomPriority(); // Assign a random priority
                return ticket;
            });
            setTickets(Array.isArray(ticketsWithUsers) ? ticketsWithUsers : []);
        };
        getTickets();
    }, []);

    const priorityGroups = { "No Priority": [], "Urgent": [], "High": [], "Medium": [], "Low": [] };
    const statusGroups = {
        "Todo": [],
        "In progress": [],
        "Backlog": [],
        "Done": [],
        "Canceled": []
    };

    const groupedTickets = tickets.reduce((acc, ticket) => {
        let groupKey;

        if (groupBy === 'priority') {
            // Grouping by priority
            groupKey = ticket.priority || "No Priority";
            if (!acc[groupKey]) acc[groupKey] = [];
        } else if (groupBy === 'user') {
            // Grouping by user, only include predefined users
            groupKey = ticket.user;
            if (!predefinedUsers[groupKey]) return acc; // Skip if user is not predefined
            if (!acc[groupKey]) acc[groupKey] = [];
        } else {
            // Grouping by status with default status groups
            groupKey = ticket.status || "Unassigned";
            if (!acc[groupKey]) acc[groupKey] = [];
        }

        acc[groupKey].push(ticket);
        return acc;
    }, groupBy === 'priority' ? { ...priorityGroups } : groupBy === 'status' ? { ...statusGroups } : {});

    Object.keys(groupedTickets).forEach(group => {
        groupedTickets[group] = groupedTickets[group].sort((a, b) => {
            if (orderBy === 'priority') return a.priority - b.priority;
            if (orderBy === 'title') return a.title.localeCompare(b.title);
            return 0;
        });
    });

    const renderPriorityIcon = (priority) => {
        switch (priority) {
            case 'Urgent':
                return <img src={Urgent} alt="Urgent Priority" style={iconStyle} />;
            case 'High':
                return <img src={highPriorityIcon} alt="High Priority" style={iconStyle} />;
            case 'Medium':
                return <img src={mediumPriorityIcon} alt="Medium Priority" style={iconStyle} />;
            case 'Low':
                return <img src={lowPriorityIcon} alt="Low Priority" style={iconStyle} />;
            case 'No Priority':
                return <img src={noPriorityIcon} alt="No Priority" style={iconStyle} />;
            default:
                return null;
        }
    };

    const renderStatusIcon = (status) => {
        switch (status) {
            case 'Todo':
                return <img src={todoIcon} alt="Todo Icon" style={iconStyle} />;
            case 'In progress':
                return <img src={inprogressIcon} alt="In Progress Icon" style={iconStyle} />;
            case 'Backlog':
                return <img src={backlogIcon} alt="Backlog Icon" style={iconStyle} />;
            case 'Done':
                return <img src={doneIcon} alt="Done Icon" style={iconStyle} />;
            case 'Canceled':
                return <img src={canceledIcon} alt="Canceled Icon" style={iconStyle} />;
            default:
                return null;
        }
    };

    const renderUserAvatar = (user) => (
        <img
            src={predefinedUsers[user]}
            alt={`${user} Avatar`}
            style={avatarStyle}
        />
    );

    const renderRandomPictureOrLetter = () => {
        if (groupBy === 'user') return null;
        const useLetter = Math.random() < 0.5; // 50% chance to use a letter or an image
        const circleStyle = {
            width: '30px', // Set the diameter of the circle
            height: '30px', // Set the diameter of the circle
            borderRadius: '50%', // Make it circular
            display: 'flex', // Use flexbox to center content
            alignItems: 'center', // Center vertically
            justifyContent: 'center', // Center horizontally
            backgroundColor: '#e0e0e0', // Light gray background
            overflow: 'hidden', // Ensure content is clipped
        };
    
        if (useLetter) {
            return (
                <div style={circleStyle}>
                    <span style={{ color: '#555', fontSize: '16px' }}>{getRandomLetter()}</span>
                </div>
            );
        } else {
            const randomImage = randomUserImages[Math.floor(Math.random() * randomUserImages.length)];
            return (
                <div style={circleStyle}>
                    <img src={randomImage} alt="Random" style={{ width: '100%', height: '100%', borderRadius: '50%' }} />
                </div>
            );
        }
    };
    

    return (
        <div>
            <div style={optionsBarStyle}>
                <div style={{ position: 'relative' }}>
                    <button
                        onClick={() => setDisplayOptionsOpen(!displayOptionsOpen)}
                        style={{
                            ...optionsButtonStyle,
                            display: 'flex',
                            alignItems: 'center',
                            color: 'black'
                        }}
                    >
                        <img src={displayIcon} alt="Display Icon" style={iconStyle} />
                        <span style={{ margin: '0 5px' }}>Display</span>
                        <img src={downIcon} alt="Dropdown Arrow" style={{ width: '16px', height: '16px' }} />
                    </button>
                    {displayOptionsOpen && (
                        <div style={dropdownStyle}>
                            <div>
                                <label>Grouping:</label>
                                <select
                                    value={groupBy}
                                    onChange={(e) => setGroupBy(e.target.value)}
                                    style={dropdownSelectStyle}
                                >
                                    <option value="status">Status</option>
                                    <option value="user">User</option>
                                    <option value="priority">Priority</option>
                                </select>
                            </div>
                            <div>
                                <label>Ordering:</label>
                                <select
                                    value={orderBy}
                                    onChange={(e) => setOrderBy(e.target.value)}
                                    style={dropdownSelectStyle}
                                >
                                    <option value="title">Title</option>
                                    <option value="priority">Priority</option>
                                </select>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            <div style={boardStyle}>
            {Object.keys(groupedTickets).map((group) => (
    <div key={group} style={columnStyle}>
        <h2 style={{ ...groupTitleStyle, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
                {groupBy === 'priority' ? renderPriorityIcon(group) : renderStatusIcon(group)} 
                <span style={{ marginLeft: '5px' }}>{group}</span> {/* Group name with margin */}
                <span style={{ marginLeft: '5px' }}>{groupedTickets[group].length}</span> {/* Count */}
            </div>
            <div>
                <img src={addIcon} alt="Add Icon" style={{ width: '20px', height: '20px', marginLeft: '10px' }} /> {/* Add icon */}
                <img src={threeDotsIcon} alt="Menu Icon" style={{ width: '20px', height: '20px', marginLeft: '5px' }} /> {/* 3 dot menu icon */}
            </div>
        </h2>
        <div style={columnContentStyle}>
            {groupedTickets[group].map((ticket) => (
                <div key={ticket.id} style={cardStyle}>
                    <div style={headerStyle}>
                        <span style={ticketIdStyle}>{ticket.id}</span>
                        {groupBy === 'user' ? renderUserAvatar(ticket.user) : renderRandomPictureOrLetter()}
                    </div>
                    <div style={titleStyle}>{ticket.title}</div>
                    {/* Render Feature Request Box */}
                    <div style={featureRequestContainerStyle}>
                        {groupBy !== 'priority' && (
                            <div style={urgentPriorityBoxStyle}>
                                {renderPriorityIcon(ticket.priority)}
                            </div>
                        )}
                        <div style={featureRequestBoxStyle}>
                            <span style={greyCircleStyle}></span>
                            <span style={featureRequestTextStyle}>Feature Request</span>
                        </div>
                    </div>
                </div>
            ))}
            {groupedTickets[group].length === 0 && (
                <p style={noTicketsStyle}>No tickets</p>
            )}
        </div>
    </div>
))}



            </div>
        </div>
    );
};

// CSS styles
const optionsBarStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '10px',
};

const optionsButtonStyle = {
    padding: '10px',
    borderRadius: '5px',
    backgroundColor: '#f0f0f0',
    border: 'none',
    cursor: 'pointer',
};

const dropdownStyle = {
    position: 'absolute',
    top: '100%',
    left: '0',
    backgroundColor: 'white',
    border: '1px solid #ccc',
    padding: '10px',
    zIndex: 1000,
};

const dropdownSelectStyle = {
    margin: '0 5px',
};

const boardStyle = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
};

const columnStyle = {
    width: '25%',
    padding: '10px',
    marginRight: '10px',
};

const groupTitleStyle = {
    fontSize: '20px',
    marginBottom: '10px',
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#e0e0e0', // Light gray background for header
    padding: '10px',
    borderRadius: '5px', // Rounded corners for header
};

const columnContentStyle = {
    display: 'flex',
    flexDirection: 'column',
};

const cardStyle = {
    backgroundColor: '#f7f7f7', // Light gray background for cards
    padding: '10px',
    borderRadius: '5px',
    marginBottom: '10px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', // Soft shadow for cards
};

const headerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
};

const ticketIdStyle = {
    fontWeight: 'bold',
};

const titleStyle = {
    fontSize: '16px',
    margin: '5px 0',
};

const featureRequestContainerStyle = {
    display: 'flex',
    alignItems: 'center',
};

const urgentPriorityBoxStyle = {
    marginRight: '5px',
};

const featureRequestBoxStyle = {
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    padding: '5px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    flex: '1',
    maxWidth: '150px', // Adjust this value as needed
    overflow: 'hidden', // Hide overflow content
    textOverflow: 'ellipsis', // Add ellipsis for overflow text
    whiteSpace: 'nowrap' // Prevent text wrapping
};


const greyCircleStyle = {
    width: '8px',
    height: '8px',
    backgroundColor: 'grey',
    borderRadius: '50%',
    marginRight: '5px',
};

const featureRequestTextStyle = {
    color: 'grey',
};

const noTicketsStyle = {
    color: 'grey',
};

const iconStyle = {
    width: '20px',
    height: '20px',
    marginRight: '5px',
};

const randomLabelStyle = {
    fontSize: '16px',
    color: '#555',
};

const avatarStyle = {
    width: '30px',
    height: '30px',
    borderRadius: '50%',
};

const randomImageStyle = {
    width: '20px',
    height: '20px',
};




export default Board;
