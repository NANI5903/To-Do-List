// src/components/Column.js
import React from 'react';
import TicketCard from './TicketCard';
import { Droppable } from 'react-beautiful-dnd';

const Column = ({ title, tickets }) => (
    <div className="column">
        <h2>{title}</h2>
        <Droppable droppableId={title}>
            {(provided) => (
                <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className="ticket-list"
                >
                    {tickets.map((ticket, index) => (
                        <TicketCard key={ticket.id} ticket={ticket} />
                    ))}
                    {provided.placeholder}
                </div>
            )}
        </Droppable>
    </div>
);

export default Column;
