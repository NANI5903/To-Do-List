// src/App.js
import React from 'react';
import Board from './components/Board';
import './index.css';

const App = () => (
    <div className="App">
        <h1></h1>
        <Board />
    </div>
);

export default App;
